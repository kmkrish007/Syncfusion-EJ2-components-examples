﻿using Syncfusion.Blazor.Data;
using Syncfusion.Blazor.Grids;
using Syncfusion.Blazor.Navigations;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace TestSample.Pages
{
    public partial class GridTest
    {
        protected SfGrid<EmployeeData> GridRef;
        public List<EmployeeData> Employees { get; set; }
        protected List<ContextMenuItemModel> ContextParent { get; set; }
        protected List<ContextMenuItemModel> ContextChild { get; set; }
        protected List<object> Toolbaritems { get; set; } = new List<object>();

        public Query GetEmployeesQuery(EmployeeData value)
        {
            return new Query().Where("EmployeeID", "equal", value.EmployeeID);
        }

        public Query GetOrderQuery(Order value)
        {
            return new Query().Where("CustomerID", "equal", value.CustomerID);
        }

        protected override void OnAfterRender(bool firstRender)
        {
            base.OnAfterRender(firstRender);
            if (firstRender)
            {
                SetButtons();
            }
        }

        protected override void OnInitialized()
        {
            Toolbaritems = new List<object>();
            Toolbaritems.Add("Search");
            Toolbaritems.Add(new ItemModel { Id = "print", Text = "Print" });
            Toolbaritems.Add(new ItemModel { Id = "test", Text = "Selected Only" });
            ContextParent = new List<ContextMenuItemModel>(){
                new ContextMenuItemModel { Text = "Parent Item 1", Target = ".e-content", Id = "parentItem1"},
                new ContextMenuItemModel { Text="Parent Item 2", Target=".e-content", Id="parentItem2" } };
            ContextChild = new List<ContextMenuItemModel> {
                new ContextMenuItemModel{Text="Child Item 1. Making this text long so that it can show up under / over parent context menu", Id="childItem1"}
            };
            Employees = new List<EmployeeData>{
            new EmployeeData() {EmployeeID = 1, FirstName="Nancy",  Title="Sales Representative",City="Texas", Country="USA"},
            new EmployeeData() {EmployeeID = 2, FirstName="Andrew",  Title="Vice President",City="London", Country="UK"},
            new EmployeeData() {EmployeeID = 3, FirstName="Janet",  Title="Sales",City="London", Country="UK"},
            new EmployeeData() {EmployeeID = 4, FirstName="Margaret",  Title="Sales Manager",City="London", Country="UK"},
            new EmployeeData() {EmployeeID = 5, FirstName="Steven",  Title="Inside Sales Coordinator",City="Vegas", Country="USA"},
            new EmployeeData() {EmployeeID = 6, FirstName="Smith",  Title="HR Manager",City="Dubai", Country="UAE"},
            new EmployeeData() {EmployeeID = 7, FirstName="Steven",  Title="Inside Sales Coordinator",City="Paris", Country="France"},
            new EmployeeData() {EmployeeID = 8, FirstName="Smith",  Title="HR Manager",City="Mumbai", Country="India"},
            new EmployeeData() {EmployeeID = 9, FirstName="Smith",  Title="HR Manager",City="Chennai", Country="India"},
        };
        }

        protected Task RowDeselected() => SetButtons();

        protected Task RowSelected() => SetButtons();

        protected Task SetButtons()
        {
            var count = GridRef?.SelectedRecords?.Count ?? 0;
            var enabled = new List<string>();
            var disabled = new List<string>();
            if (count == 0)
            {
                enabled.Add("print");
                disabled.Add("test");
            }
            else
            {
                enabled.Add("test");
                disabled.Add("print");
            }
            GridRef?.EnableToolbarItems(enabled, true);
            GridRef?.EnableToolbarItems(disabled, false);
            return Task.CompletedTask;
        }
    }

    #region Helper Classes

    public class EmployeeData
    {
        public int? EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string Title { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
    }

    public class Order
    {
        public int? EmployeeID { get; set; }
        public int? OrderID { get; set; }
        public string CustomerID { get; set; }
        public string ShipName { get; set; }
        public string ShipCity { get; set; }
        public double? Freight { get; set; }
    }

    public class CustomerDetails
    {
        public string CustomerID { get; set; }
        public string ContactTitle { get; set; }
        public string Country { get; set; }
        public string Address { get; set; }
    }

    #endregion
}