﻿using Syncfusion.Blazor.Navigations;
using System;
using System.Collections.Generic;
using System.Threading;

namespace TestSample.Pages
{
    public partial class TreeTest
    {
        private static readonly Random Random = new Random(DateTime.Now.Second);
        protected static List<TestModel> Nodes { get; set; }

        protected SfTreeView<TestModel> TreeRef { get; set; }
        protected string SelectedText { get; set; }

        protected override void OnInitialized()
        {
            base.OnInitialized();

            if (Nodes == null)
            {
                Nodes = new List<TestModel>();
                Nodes.Add(new TestModel("pre"));
                Nodes.Add(new TestModel("first"));
            }
        }

        protected void OnNodeSelected(NodeSelectEventArgs e)
        {
            SelectedText = e.NodeData.Text;
            StateHasChanged();
        }

        protected void AddNode()
        {
            var rand = Random.Next(100, 999);  // just to make sure is something different
            Nodes.Add(new TestModel($"child of pre: {rand}") { ParentKey = Nodes[0].Key });
            //TreeRef.Refresh();  // doesn't work. blanks out the tree
            TreeRef.DataBind(false); // doesn't seem to do anything?
            StateHasChanged();
        }
    }

    #region Helper class

    public class TestModel
    {
        private static int GID = 0;
        public int Key { get; set; }
        public int? ParentKey { get; set; }
        public string Title { get; set; }
        public bool Expanded { get; set; }
        public bool Selected { get; set; }
        public string IconCss { get; }

        public TestModel(string title)
        {
            Interlocked.Increment(ref GID);
            Key = GID;
            Title = title;
            IconCss = "";
            Expanded = true;
            Selected = false;
        }
    }

    #endregion
}